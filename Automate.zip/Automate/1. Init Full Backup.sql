BACKUP DATABASE [Adventureworks] 
TO  [myDevice] 
WITH FORMAT,MEDIANAME = N'myMedia'
